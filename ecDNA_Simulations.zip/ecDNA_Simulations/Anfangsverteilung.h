/*
 *  Anfangsverteilung.h
 *  
 *
 *  Created by Benjamin Werner on 10/31/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

# include <iostream>
# include <cmath>
# include <ctime>
# include <cstdlib>
# include <cstdio>
# include <vector>
# include <fstream>
#include <math.h>

using std::vector;
using std::cout;
using std::cin;